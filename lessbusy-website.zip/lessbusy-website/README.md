# Lessbusy marketing website

A responsive, static marketing site built from the supplied Lessbusy product concept and logo. Its visual direction now follows the supplied landing-page reference: vivid pink, ink outlines, pill navigation, playful type, hard offset shadows, colorful cards and motion accents. The unrelated beverage brand copy and imagery were replaced with Lessbusy product content and original interface illustrations.

## Run locally

Serve this directory with any static web server. For example, from this folder run:

```sh
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## Included

- Responsive landing page with section navigation and a mobile menu.
- Interactive platform area selector, eight-step sales workflow, business-type selector, native FAQ disclosures and a sample-only AI assistant preview.
- Custom CSS product interface illustrations and the supplied Lessbusy logo, recomposed for the website header and favicon.
- Page metadata, social sharing tags, keyboard focus styles, a skip link and reduced-motion handling.

## Production configuration

This is a frontend marketing site. The supplied materials do not include a live product endpoint, account creation, demo-request backend, pricing, analytics, authentication, CRM, or messaging credentials. The supplied phone numbers now open call and WhatsApp links, and the supplied @lessbusy.tech handle opens Instagram. WhatsApp links use +91 based on the 10-digit numbers and India locale; verify that country code before launch. The AI preview uses fixed sample responses and does not query a model or business data. There is no contact form that would appear to accept data without delivering it.

Before launch, connect any verified sign-up or demo-request destination, configure the production domain and social preview image, and confirm feature availability and wording with the product team. WhatsApp and Instagram product integrations depend on compatible provider accounts, permissions and configuration. The site describes the intended product concept; workspace isolation, role enforcement, backups and other product security controls must be implemented and verified in the deployed service.

No customer testimonials, performance metrics, pricing, certifications or unsupported integration claims are included.
